INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (1, 22, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (1, 22, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (1, 31, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (2, 23, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (3, 24, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (3, 32, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (3, 33, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (4, 34, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (5, 35, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (6, 36, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (6, 37, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (7, 28, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (7, 38, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (7, 39, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (8, 38, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (8, 40, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (9, 41, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (10, 42, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (10, 43, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (10, 44, 'SC' )
       /
       