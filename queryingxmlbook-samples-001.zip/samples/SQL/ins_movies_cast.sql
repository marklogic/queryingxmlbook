INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 31, 'Korben Dallas' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 32, 'Jean-Baptiste Emanuel Zorg' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 33, 'Vito Cornelius' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 34, 'Leeloo' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 35, 'Ruby Rhod' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 36, 'David Kessler' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 37, 'Alex Price' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 38, 'Jack Goodman' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 39, 'Dr. Hirsch' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 40, 'Curt Henderson' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 41, 'Steve Bolander' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 42, 'John Milner' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 43, 'Terry "The Toad" Fields' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 44, 'Lester Burnham' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 45, 'Carolyn Burnham' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 46, 'Jane Burnham' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 47, 'Angela Hayes' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 48, 'Ricky Fitts' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 32, 'Egor Korshunov ' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 49, 'James Marshall' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 50, 'Kathryn Bennett' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 51, 'Major Caldwell' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 52, 'Alice Marshall' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 53, 'Grace Marshall' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 55, 'A. Dallas' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 56, 'J. Lambert' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 57, 'S. E. Brett' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 58, 'G. E. Kanet' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (7, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (7, 59, 'Dwayne Hicks' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (7, 60, 'Carter J. Burke' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (8, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (8, 61, 'Bishop II' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (8, 62, 'Dillon' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (9, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (9, 63, 'Annalee Call' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (9, 64, 'Johner' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (10, 65, 'John ''Bluto'' Blutarsky ' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (10, 66, 'Eric ''Otter'' Stratton' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (10, 67, 'Vernon Wormer ' )
       /
       