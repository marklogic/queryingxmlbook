INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (1, 'Y', 'Y', 'Y', 'English 2-channel, Spanish' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (2, 'Y', 'Y', 'N', 'Mono' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (3, 'N', 'N', 'Y', 'Dolby Surround, French 2-channel' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (4, 'Y', 'Y', 'N', 'Dolby Surround' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (5, 'Y', 'N', 'N', 'Englsih 2-channel, French, Spanish' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (6, 'Y', 'N', 'Y', 'Dolby Surround, French Surround' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (7, 'Y', 'N', 'Y', 'Dolby Surround' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (8, 'Y', 'N', 'Y', 'Dolby Surround, French' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (9, 'Y', 'N', 'Y', 'Dolby Surround, French' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (10, 'N', 'N', 'N', 'English 2-channel mono, French 2-channel mono, Spanish 2-channel mono ' )
       /
       