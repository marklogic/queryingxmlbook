

CREATE TABLE MOVIES (
  ID                 INT ,
  TITLE              VARCHAR2(40) ,
  MY_STARS           INT ,
  YEAR_RELEASED      INT ,
  RUNNING_TIME       INT ,
  STUDIO             VARCHAR2(60) ,
  TAGLINE            VARCHAR2(200) ,
  PLOT_SUMMARY       VARCHAR2(1000) ,
  MPAA_RATING        VARCHAR2(5) ,
  ASPECT_RATIO       VARCHAR2(8)
  )
/

  
CREATE TABLE PERSONS (
  ID                 INT ,
  FAMILY_NAME        VARCHAR2(20) ,
  GIVEN_NAME         VARCHAR2(20) ,
  OTHER_NAMES        VARCHAR2(120) 
  )
/

CREATE TABLE MOVIES_CAST (
  MOVIE_ID           INT ,
  PERSON_ID          INT ,
  CHARACTER          VARCHAR2(100)
)
/


CREATE TABLE SOUND (
  DOLBY_DIGITAL_51   CHAR(1) ,
  DTS_51             CHAR(1) ,
  THX                CHAR(1) ,
  OTHER              VARCHAR2(200)
  )
/

CREATE TABLE MOVIES_PRODUCERS (
  MOVIE_ID           INT ,
  PERSON_ID          INT
  )
/

CREATE TABLE MOVIES_DIRECTORS (
  MOVIE_ID           INT ,
  PERSON_ID          INT
  )
/

CREATE TABLE MOVIES_WRITERS (
  MOVIE_ID           INT ,
  PERSON_ID          INT ,
  STORY_OR_SCREENPLAY CHAR(2)
  )
/

-- created by Example 15-22, used in Example 15-23

DROP SEQUENCE producers_seq
/
CREATE SEQUENCE producers_seq
/

CREATE TABLE producers AS 
(
  SELECT producers_seq.nextval AS id, p.*
  from dual d, 
  (
    SELECT DISTINCT
      result."familyName",
      result."givenName",
      result."otherNames"
    FROM
      movies_xml ,
      XMLTABLE(
        'for $m in
          $col/movie
        return
          $m/producer'
        PASSING movies_xml.movie AS "col"
        COLUMNS
          "ord" FOR ORDINALITY ,
          "familyName" VARCHAR(12) PATH 'familyName' ,
          "givenName" VARCHAR(12) PATH 'givenName' DEFAULT 'none' ,
          "otherNames" VARCHAR(12) PATH 'otherNames' DEFAULT 'none'
       ) AS result 
     )  p
  )
/   

-- test Example 15-23:

CREATE TABLE MOVIES_PRODUCERS_TEST AS (
SELECT 
  movies_xml.id AS "MOVIE",
  producers.id AS "PRODUCER"
FROM
  movies_xml ,
  producers ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m/producer'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "ord" FOR ORDINALITY ,
      "familyName" VARCHAR(12),
      "givenName" VARCHAR(12) ,
      "otherNames" VARCHAR(12)
  ) AS result
WHERE
  result."familyName" = producers."familyName" AND
  result."givenName" = producers."givenName" 
)
/

SELECT
  movies.title,
  producers."familyName"
FROM
  movies,
  producers,
  movies_producers_test
WHERE
  movies.id = movies_producers_test.movie AND
  producers.id = movies_producers_test.producer
ORDER BY
  movies.title
/
