--- SQL script to populate tables for movies-we-own.xml
--- This script was created automatically from an XQuery
----------------------------------------------------------------------


INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (1, 'The Fifth Element', 3, 1997, 126, 'Tristar Studios', 'It must be found', 'Two hundred and fifty years in the future, life as we know it is threatened by the arrival of Evil. Only the fifth element (played by Milla Jovovich) can stop the Evil from extinguishing life, as it tries to do every five thousand years. She is helped by ex-soldier, current-cab-driver, Corben Dallas (played by Bruce Willis), who is, in turn, helped by Prince/Arsenio clone, Ruby Rhod. Unfortunately, Evil is being assisted by Mr. Zorg (Gary Oldman), who seeks to profit from the chaos that Evil will bring, and his alien mercenaries. ', 'PG-13', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (2, 'An American Werewolf in London', 5, 1981, 98, 'Universal Studios', 'From the director of Animal House - - a differnt kind of animal. ', 'Its a rainy night on the Welsh moors.  Two American students on a walking tour of Europe trudge on to the next town,when suddenly the air is pierced by an unearthly howl... Three weeks later, one is dead, the other is in the hospital and the nightmare begins for An American Werewolf in London.', 'R', '1.85:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (3, 'American Graffiti', 3, 1973, 110, 'Universal Studios', 'Where were you in 62?', 'The coming of age of four teenagers on their last summer night before college.', 'PG', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (4, 'American Beauty', 5, 1999, 121, '', '...look closer', 'A man tells his tale of how he turned his miserable life around and turned everyone elses upside down as a result.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (5, 'Air Force One', 2, 1997, 124, '', 'The fate of the nation rests on the courage of one man.', 'A gripping thriller about a steadfast U.S. President who has just told the world he will not negotiate with terrorists.  Now, Russian neo-nationalists have hijacked Air Force One, and the President is faced with a nearly impossible decision - give in to the terroists demands or sacrifice not only the countrys dignity, but the lives of his wife and daughter.  ', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (6, 'Alien', 4, 1979, 117, '20th Century Fox', 'In space no one can hear you scream.', 'The terror begins when the crew of the spaceship Nostromo investigates a transmission from a desolate planet and makes a horrifying discovery - a life form that breeds within a human host.  Now the crew must fight not only for its own survival, but for the survival of all mankind.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (7, 'Aliens', 4, 1986, 154, '20th Century Fox', 'This time its war.', 'As the only survivor from mankinds first encounter with the monstrous Alien, Ripleys account of the Alien and the fate of her crew are recieved with skepticism - until the mysterious disappearance of colonists on LV-426 lead her to join a team of high-tech colonial marines sent in to investigate.  ', 'R', '1.85:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (8, 'Alien 3', 4, 1992, 115, '20th Century Fox', 'The bitch is back', 'Lt. Ripley is the lone survivor when her crippled spaceship crash lands on Fiorina 161, a bleak wasteland inhabited by former inmates of the planets maximum security prison.  Ripleys fears that an Alien was aboard her craft are confirmed when the mutilated bodies of ex-cons begin to mount.  Without weapons or modern technology of any kind, Ripley must lead the men into battle against the terrifying creature.  And soon she discovers a horrifying fact about her link with the Alien, a realization that may compel Ripley to try destoying not only the horrific creature, but herself as well.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (9, 'Alien Resurrection', 3, 1997, 108, '20th Century Fox', 'Witness the resurrection', 'Ellen Ripley died fighting the perfect predator.  Two hundred years and wight horrific experiments later, shes back.  A group of scientists has cloned her - along with the alien queen inside her - hoping to breed the ultimate weapon.  But the resurrected Ripley is full of surprises for her creators, as are the aliens.  And soon, a lot more than all hell breaks loose!   To combat the creatures, Ripleymust team up with a band of smugglers, including a mechanic named Call, who holds more than a few surprises of her own.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (10, 'Animal House', 5, 1978, 109, '', 'It was the Deltas against the rules... the rules lost!', 'At a 1962 College, Dean Vernon Wormer is determined to expel the Delta House Fraternity, but those roughhousers have other plans for him. ', 'R', '1.85:1'  )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (1, 'Amicarella', 'John', 'C.' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (2, 'Ledoux', 'Patrice', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (3, 'Smith', 'Iain', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (4, 'Folsey', 'George, Jr.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (5, 'Guber', 'Peter', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (6, 'Peters', 'Jon', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (7, 'Coppola', 'Francis Ford', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (8, 'Kurtz', 'Gary', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (9, 'Cohen', 'Bruce', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (10, 'Jinks', 'Dan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (11, 'Bernstein', 'Armyan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (12, 'Peterson', 'Wolfgang', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (13, 'Katz', 'Gail', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (14, 'Shestack', 'Jon', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (15, 'Carroll', 'Gordon', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (16, 'Giler', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (17, 'Hurd', 'Gale Ann', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (18, 'Hill', 'Walter', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (19, 'Badalato', 'Bill', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (20, 'Simmons', 'Matty', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (21, 'Reitman', 'Ivan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (22, 'Besson', 'Luc', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (23, 'Landis', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (24, 'Lucas', 'George', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (25, 'Mendes', 'Sam', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (26, 'Peterson', 'Wolfgang', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (27, 'Scott', 'Ridley', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (28, 'Cameron', 'James', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (29, 'Fincher', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (30, 'Jeunet', 'Jean-Pierre', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (31, 'Willis', 'Bruce', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (32, 'Oldman', 'Gary', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (33, 'Holm', 'Ian', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (34, 'Jovovich', 'Milla', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (35, 'Tucker', 'Chris', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (36, 'Naughton', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (37, 'Agutter', 'Jenny', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (38, 'Dunne', 'Griffin', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (39, 'Woodvine', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (40, 'Dreyfuss', 'Richard', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (41, 'Howard', 'Ronny', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (42, 'Le Mat', 'Paul', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (43, 'Smith', 'Charlie Martin', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (44, 'Spacey', 'Kevin', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (45, 'Bening', 'Annette', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (46, 'Birch', 'Thora', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (47, 'Suvari', 'Mena', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (48, 'Bentley', 'Wes', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (49, 'Ford', 'Harrison', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (50, 'Close', 'Glenn', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (51, 'Macy', 'William H.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (52, 'Matthews', 'Liesel', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (53, 'Crewson', 'Wendy', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (54, 'Weaver', 'Sigourney', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (55, 'Skerritt', 'Tom', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (56, 'Cartwright', 'Veronica', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (57, 'Stanton', 'Harry Dean', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (58, 'Hurt', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (59, 'Biehn', 'Micheal', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (60, 'Reiser', 'Paul', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (61, 'Henriksen', 'Lance', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (62, 'Dutton', 'Charles S.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (63, 'Ryder', 'Winina', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (64, 'Perlman', 'Ron', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (65, 'Belushi', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (66, 'Matheson', 'Tim', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (67, 'Vernon', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (68, 'Kamen', 'Robert', 'Mark' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (69, 'Katz', 'Gloria', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (70, 'Huyck', 'Willard', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (71, 'Ball', 'Alan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (72, 'Marlowe', 'Andrew W.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (73, 'O''Bannon', 'Dan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (74, 'Shusett', 'Ronald', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (75, 'Giler', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (76, 'Hill', 'Walter', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (77, 'Ward', 'Vincent', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (78, 'Whedon', 'Joss', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (79, 'Kenney', 'Douglas', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (80, 'Ramis', 'Harold', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (81, 'Miller', 'Chris', '' )
      /
      
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 31, 'Korben Dallas' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 32, 'Jean-Baptiste Emanuel Zorg' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 33, 'Vito Cornelius' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 34, 'Leeloo' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (1, 35, 'Ruby Rhod' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 36, 'David Kessler' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 37, 'Alex Price' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 38, 'Jack Goodman' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (2, 39, 'Dr. Hirsch' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 40, 'Curt Henderson' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 41, 'Steve Bolander' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 42, 'John Milner' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (3, 43, 'Terry "The Toad" Fields' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 44, 'Lester Burnham' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 45, 'Carolyn Burnham' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 46, 'Jane Burnham' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 47, 'Angela Hayes' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (4, 48, 'Ricky Fitts' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 32, 'Egor Korshunov ' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 49, 'James Marshall' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 50, 'Kathryn Bennett' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 51, 'Major Caldwell' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 52, 'Alice Marshall' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (5, 53, 'Grace Marshall' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 55, 'A. Dallas' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 56, 'J. Lambert' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 57, 'S. E. Brett' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (6, 58, 'G. E. Kanet' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (7, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (7, 59, 'Dwayne Hicks' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (7, 60, 'Carter J. Burke' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (8, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (8, 61, 'Bishop II' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (8, 62, 'Dillon' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (9, 54, 'Ellen Ripley' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (9, 63, 'Annalee Call' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (9, 64, 'Johner' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (10, 65, 'John ''Bluto'' Blutarsky ' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (10, 66, 'Eric ''Otter'' Stratton' )
       /
       
INSERT INTO MOVIES_CAST (
       MOVIE_ID ,
       PERSON_ID ,
       CHARACTER
       )
       VALUES (10, 67, 'Vernon Wormer ' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (1, 'Y', 'Y', 'Y', 'English 2-channel, Spanish' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (2, 'Y', 'Y', 'N', 'Mono' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (3, 'N', 'N', 'Y', 'Dolby Surround, French 2-channel' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (4, 'Y', 'Y', 'N', 'Dolby Surround' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (5, 'Y', 'N', 'N', 'Englsih 2-channel, French, Spanish' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (6, 'Y', 'N', 'Y', 'Dolby Surround, French Surround' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (7, 'Y', 'N', 'Y', 'Dolby Surround' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (8, 'Y', 'N', 'Y', 'Dolby Surround, French' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (9, 'Y', 'N', 'Y', 'Dolby Surround, French' )
       /
       
INSERT INTO MOVIES_SOUND (
     MOVIE_ID ,
     DOLBY_DIGITAL_51 ,
     DTS_51 ,
     THX ,
     OTHER
     )
     VALUES (10, 'N', 'N', 'N', 'English 2-channel mono, French 2-channel mono, Spanish 2-channel mono ' )
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 1)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 2)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 3)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 4)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 5)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 6)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (3, 7)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (3, 8)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (4, 9)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (4, 10)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 11)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 12)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 13)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 14)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (6, 15)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (6, 16)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (7, 17)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 15)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 16)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 18)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 15)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 16)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 18)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 19)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (10, 20)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (10, 21)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 22)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 23)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (3, 24)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (4, 25)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 26)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (6, 27)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (7, 28)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 29)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 30)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (10, 23)
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (1, 22, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (1, 22, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (1, 31, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (2, 23, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (3, 24, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (3, 32, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (3, 33, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (4, 34, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (5, 35, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (6, 36, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (6, 37, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (7, 28, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (7, 38, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (7, 39, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (8, 38, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (8, 40, 'ST' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (9, 41, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (10, 42, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (10, 43, 'SC' )
       /
       
INSERT INTO MOVIES_WRITERS (
       MOVIE_ID ,
       PERSON_ID ,
       STORY_OR_SCREENPLAY
       )
       VALUES (10, 44, 'SC' )
       /
       
commit
/
