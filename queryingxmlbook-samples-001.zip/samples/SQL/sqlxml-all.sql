-- 15-1

SELECT
  XMLELEMENT(NAME "title", title) AS "Movie Titles"
  FROM movies
/

-- 15-2

SELECT
  XMLELEMENT(NAME title,
    XMLATTRIBUTES(running_time AS "RunningTime"),
      'This movie title is '||m.title)
        AS "Movie Titles"
  FROM movies m
/

-- 15-4

SELECT
  XMLELEMENT(NAME "all-titles",
    XMLAGG(XMLELEMENT(NAME "title", title) ORDER BY year_released ASC ) )
      AS "Movie Titles"
  FROM movies
/

-- 15-5

SELECT
  XMLELEMENT(NAME "movie-details",
    XMLELEMENT(NAME "title", title) ,
    XMLELEMENT(NAME "yearReleased", year_released) ,
    XMLELEMENT(NAME "runningTime", running_time)
    ) AS "Movie Details"
  FROM movies
  WHERE
    year_released = 1997
/

-- 15-6

SELECT
  XMLELEMENT(NAME "movie-details",
    XMLFOREST(
      title AS "title" ,
      year_released AS "yearReleased" ,
      running_time AS "runningTime")
    ) AS "Movie Details"
  FROM movies
  WHERE
    year_released = 1997
/

-- 15-7

SELECT
  XMLELEMENT(NAME "producer-details",
    XMLELEMENT(NAME "givenName", given_name) ,
    XMLELEMENT(NAME "familyName", family_name) ,
    XMLELEMENT(NAME "otherNames", other_names)
    ) AS "Producer Details"
  FROM persons
  WHERE
    id IN (
      SELECT distinct(producer_id) FROM movies_producers
      WHERE movie_id IN (
        SELECT id FROM movies WHERE running_time > 125
        )
      )
/

-- 15-8

SELECT
  XMLELEMENT(NAME "producer-details",
    XMLFOREST(
      given_name AS "givenName" ,
      family_name AS "familyName" ,
      other_names AS "otherNames"
      )
    ) AS "Producer Details"
  FROM persons
  WHERE
    id IN (
      SELECT distinct(producer_id) FROM movies_producers
      WHERE movie_id IN (
        SELECT id FROM movies WHERE running_time > 125
        )
      )
/

-- 15-9

SELECT
  XMLCONCAT(
      XMLELEMENT("givenName", given_name) ,
      XMLELEMENT("familyName", family_name) ,
      XMLELEMENT("otherNames", other_names)
      ) AS "Producer Details"
  FROM persons
  WHERE
    id IN (
      SELECT distinct(producer_id) FROM movies_producers
      WHERE movie_id IN (
        SELECT id FROM movies WHERE running_time > 125
        )
      )
/

-- 15-10

SELECT
  XMLQUERY(
    'for $m in
      $col/movie
    return
      $m/title'
    PASSING movie AS "col"
    RETURNING CONTENT
  ) AS result
FROM MOVIES_XML

-- 15-24

SELECT 
  result."yearReleased",
  result."director",
  avg(result."runningTime") AS "length"
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "yearReleased" NUMBER PATH 'yearReleased' ,
      "producers" XMLTYPE PATH 'producer',
      "runningTime" NUMBER PATH 'runningTime',
      "director" VARCHAR(12) PATH 'director[1]/familyName'
  ) AS result
  WHERE result."yearReleased" IN (1997, 1998, 1999)
  GROUP BY
    rollup(result."yearReleased", result."director" )
  ORDER BY result."yearReleased" ASC

-- 15-25
SELECT 
  result."yearReleased",
  result."director",
  avg(result."runningTime") AS "length"
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "yearReleased" NUMBER PATH 'yearReleased' ,
      "producers" XMLTYPE PATH 'producer',
      "runningTime" NUMBER PATH 'runningTime',
      "director" VARCHAR(12) PATH 'director[1]/familyName'
  ) AS result
  WHERE result."yearReleased" IN (1997, 1998, 1999)
  GROUP BY
    cube(result."yearReleased", result."director" )
  ORDER BY result."yearReleased" ASC
