CREATE TABLE all_movies_xml (
  ID                 INT ,
  ALL_MOVIES         XMLType
)
/
-- requires CREATE DIRECTORY privilege
CREATE DIRECTORY xmldir AS 'C:\stage'
/
INSERT INTO all_movies_xml ( 
  ID , 
  ALL_MOVIES 
  ) 
VALUES ( 
  1 , 
  XMLType( bfilename('XMLDIR', 'movies-we-own.xml'), 
           nls_charset_id('AL32UTF8') )
  )
/
