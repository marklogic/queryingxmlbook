INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (1, 'The Fifth Element', 3, 1997, 126, 'Tristar Studios', 'It must be found', 'Two hundred and fifty years in the future, life as we know it is threatened by the arrival of Evil. Only the fifth element (played by Milla Jovovich) can stop the Evil from extinguishing life, as it tries to do every five thousand years. She is helped by ex-soldier, current-cab-driver, Corben Dallas (played by Bruce Willis), who is, in turn, helped by Prince/Arsenio clone, Ruby Rhod. Unfortunately, Evil is being assisted by Mr. Zorg (Gary Oldman), who seeks to profit from the chaos that Evil will bring, and his alien mercenaries. ', 'PG-13', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (2, 'An American Werewolf in London', 5, 1981, 98, 'Universal Studios', 'From the director of Animal House - - a different kind of animal. ', 'It''s a rainy night on the Welsh moors.  Two American students on a walking tour of Europe trudge on to the next town,when suddenly the air is pierced by an unearthly howl... Three weeks later, one is dead, the other is in the hospital and the nightmare begins for An American Werewolf in London.', 'R', '1.85:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (3, 'American Graffiti', 3, 1973, 110, 'Universal Studios', 'Where were you in ''62?', 'The coming of age of four teenagers on their last summer night before college.', 'PG', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (4, 'American Beauty', 5, 1999, 121, '', '...look closer', 'A man tells his tale of how he turned his miserable life around and turned everyone else''s upside down as a result.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (5, 'Air Force One', 2, 1997, 124, '', 'The fate of the nation rests on the courage of one man.', 'A gripping thriller about a steadfast U.S. President who has just told the world he will not negotiate with terrorists.  Now, Russian neo-nationalists have hijacked Air Force One, and the President is faced with a nearly impossible decision - give in to the terroists demands or sacrifice not only the country''s dignity, but the lives of his wife and daughter.  ', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (6, 'Alien', 4, 1979, 117, '20th Century Fox', 'In space no one can hear you scream.', 'The terror begins when the crew of the spaceship Nostromo investigates a transmission from a desolate planet and makes a horrifying discovery - a life form that breeds within a human host.  Now the crew must fight not only for its own survival, but for the survival of all mankind.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (7, 'Aliens', 4, 1986, 154, '20th Century Fox', 'This time it''s war.', 'As the only survivor from mankinds first encounter with the monstrous Alien, Ripley''s account of the Alien and the fate of her crew are recieved with skepticism - until the mysterious disappearance of colonists on LV-426 lead her to join a team of high-tech colonial marines sent in to investigate.  ', 'R', '1.85:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (8, 'Alien 3', 4, 1992, 115, '20th Century Fox', 'The bitch is back', 'Lt. Ripley is the lone survivor when her crippled spaceship crash lands on Fiorina 161, a bleak wasteland inhabited by former inmates of the planet''s maximum security prison.  Ripley''s fears that an Alien was aboard her craft are confirmed when the mutilated bodies of ex-cons begin to mount.  Without weapons or modern technology of any kind, Ripley must lead the men into battle against the terrifying creature.  And soon she discovers a horrifying fact about her link with the Alien, a realization that may compel Ripley to try destoying not only the horrific creature, but herself as well.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (9, 'Alien Resurrection', 3, 1997, 108, '20th Century Fox', 'Witness the resurrection', 'Ellen Ripley died fighting the perfect predator.  Two hundred years and wight horrific experiments later, she''s back.  A group of scientists has cloned her - along with the alien queen inside her - hoping to breed the ultimate weapon.  But the resurrected Ripley is full of surprises for her "creators," as are the aliens.  And soon, a lot more than "all hell" breaks loose!   To combat the creatures, Ripleymust team up with a band of smugglers, including a mechanic named Call, who holds more than a few surprises of her own.', 'R', '2.35:1'  )
      /
      
INSERT INTO MOVIES (
      ID ,
      TITLE ,
      MY_STARS ,
      YEAR_RELEASED ,
      RUNNING_TIME ,
      STUDIO ,
      TAGLINE ,
      PLOT_SUMMARY ,
      MPAA_RATING ,
      ASPECT_RATIO
      )
      VALUES (10, 'Animal House', 5, 1978, 109, '', 'It was the Deltas against the rules... the rules lost!', 'At a 1962 College, Dean Vernon Wormer is determined to expel the Delta House Fraternity, but those roughhousers have other plans for him. ', 'R', '1.85:1'  )
      /
      