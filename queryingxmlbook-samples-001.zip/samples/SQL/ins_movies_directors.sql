INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 22)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 23)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (3, 24)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (4, 25)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 26)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (6, 27)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (7, 28)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 29)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 30)
       /
       
INSERT INTO MOVIES_DIRECTORS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (10, 23)
       /
       