-- SQL script to populate reviews table from reviews.xml
-- produced automatically with cre_table_reviews.xsl
spool ins_reviews.log
set echo on
drop sequence reviews_xml_seq;
    create sequence reviews_xml_seq;
    drop table reviews_xml;
    create table reviews_xml(ID number, review XMLType);
    INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>An American Werewolf in London</title><rating>5</rating><text>Great cast, great movie.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>An American Werewolf in London</title><rating>5</rating><text>An excellent movie.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>An American Werewolf in London</title><rating>5</rating><text>Jenny Agutter should have won an Oscar.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>An American Werewolf in London</title><rating>5</rating><text>One of my favorites.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>Animal House</title><rating>5</rating><text>Excellent cult movie.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>Animal House</title><rating>3</rating><text>Pretty good.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>Animal House</title><rating>4</rating><text>John Belushi at his best.</text></review>');
INSERT INTO reviews_xml (ID, review) values (reviews_xml_seq.nextval, '<review><medium>movie</medium><title>Animal House</title><rating>2</rating><text>This movie is awful.</text></review>');
commit
/
spool off
