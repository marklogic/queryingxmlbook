-- Example A-30


SELECT
  AVG(
    XMLCAST(
      XMLQUERY(
        'for $m in
          $col/movie
        return
          $m/runningTime/text()'
        PASSING movie AS "col"
        RETURNING CONTENT
        ) AS decimal(8,1)
      ) 
  ) AS "avgRunningTime"
FROM MOVIES_XML



