-- Example A-31


SELECT
  XMLQUERY(
    'for $m in
      $col/movie
     let $producers := $m/producer
     where $m/yearReleased < 1980
    return
      <output>
        {$m/title}
        {for $p in $producers
           return
             <prodFullName>
               {concat(
                 $p/givenName,
                 " ",
                 $p/familyName
                )
               }
             </prodFullName>
        }
      </output>'
    PASSING movie AS "col"
    RETURNING CONTENT
  ) AS "Producers"
  FROM movies_xml



