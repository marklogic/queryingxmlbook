-- Example A-36


SELECT result.* 
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    where $m/yearReleased < 1980
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producers" XMLTYPE PATH 'producer'
  ) AS result
