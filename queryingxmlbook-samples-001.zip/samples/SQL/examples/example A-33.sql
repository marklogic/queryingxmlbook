-- Example A-33


SELECT result.*
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "runningTime" INTEGER PATH 'runningTime' ,
      "yearReleased" INTEGER PATH 'yearReleased'
  ) AS result
ORDER BY
  result."runningTime"
