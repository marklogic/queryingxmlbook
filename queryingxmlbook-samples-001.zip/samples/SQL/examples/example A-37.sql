-- Example A-37


SELECT result."title", result2.* FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    where
      contains($m/title, "Alien")
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producers" XMLTYPE PATH 'producer'
  ) AS result ,
  XMLTABLE(
    'for $prod in $p/producer
     return
      $prod'
    PASSING result."producers" AS "p"
    COLUMNS
      "ord" FOR ORDINALITY ,
      "familyName" VARCHAR(20) PATH 'familyName'
  ) AS result2
