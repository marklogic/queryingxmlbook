-- Example A-22


SELECT
  XMLELEMENT(NAME "all-titles",
    XMLAGG(XMLELEMENT(NAME "title", title) ORDER BY year_released ASC ) )
      AS "Movie Titles"
  FROM movies


