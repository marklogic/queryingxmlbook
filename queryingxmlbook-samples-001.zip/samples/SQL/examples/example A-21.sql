-- Example A-21


SELECT
  XMLELEMENT(NAME title,
    XMLATTRIBUTES(running_time AS "RunningTime"),
      'This movie title is '||m.title)
        AS "Movie Titles"
  FROM movies m


