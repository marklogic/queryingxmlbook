-- Example A-41


SELECT 
  result."yearReleased",
  result."director",
  avg(result."runningTime") AS "length"
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "yearReleased" NUMBER PATH 'yearReleased' ,
      "producers" XMLTYPE PATH 'producer',
      "runningTime" NUMBER PATH 'runningTime',
      "director" VARCHAR(12) PATH 'director[1]/familyName'
  ) AS result
  WHERE result."yearReleased" IN (1997, 1998, 1999)
  GROUP BY
    rollup(result."yearReleased", result."director" )
  ORDER BY result."yearReleased" ASC

