-- Example A-27


SELECT
  XMLQUERY(
    'for $m in
      $col/movies/movie
    return
      $m/title'
    PASSING all_movies AS "col"
    RETURNING CONTENT
  ) AS result
FROM all_movies_xml


