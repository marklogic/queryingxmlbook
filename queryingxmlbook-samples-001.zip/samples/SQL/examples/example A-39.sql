-- Example A-39


CREATE SEQUENCE producers_seq
/
SELECT producers_seq.nextval AS id, p.*
from dual d, 
(
  SELECT DISTINCT
    result."familyName",
    result."givenName",
    result."otherNames"
  FROM
    movies_xml ,
    XMLTABLE(
      'for $m in
        $col/movie
      return
        $m/producer'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "familyName" VARCHAR(12) PATH 'familyName' ,
        "givenName" VARCHAR(12) PATH 'givenName' DEFAULT 'none' ,
        "otherNames" VARCHAR(12) PATH 'otherNames' DEFAULT 'none'
    ) AS result 
  )  p
/
