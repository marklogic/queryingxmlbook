-- Example A-24 


SELECT
  XMLELEMENT(NAME "producer-details",
    XMLELEMENT(NAME "givenName", given_name) ,
    XMLELEMENT(NAME "familyName", family_name) ,
    XMLELEMENT(NAME "otherNames", other_names)
    ) AS "Producer Details"
  FROM persons
  WHERE
    id IN (
      SELECT distinct(producer_id) FROM movies_producers
      WHERE movie_id IN (
        SELECT id FROM movies WHERE running_time > 125
        )
      )
