-- Example A-38


SELECT result.* FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producerF" VARCHAR(12) PATH 'producer[1]/familyName' ,
      "producerG" VARCHAR(12) PATH 'producer[1]/givenName' ,
      "producerO" VARCHAR(12) PATH 'producer[1]/otherNames' DEFAULT 'none'
  ) AS result

