-- Example A-40


SELECT 
  movies_xml.id AS "MOVIE",
  producers.id AS "PRODUCER"
FROM
  movies_xml ,
  producers ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m/producer'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "familyName" VARCHAR(12),
      "givenName" VARCHAR(12) ,
      "otherNames" VARCHAR(12)
  ) AS result
WHERE
  result."familyName" = producers."familyName" AND
  result."givenName" = producers."givenName" 
/
