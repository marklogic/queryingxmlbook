-- Example A-34


SELECT result.*
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) ,
      "runningTime" INTEGER ,
      "yearReleased" INTEGER ,
      "producer[1]/familyName" VARCHAR(20)
  ) AS result ("TITLE", "RUNNINGTIME", "YEARRELEASED", "PRODUCER")
ORDER BY
  result."RUNNINGTIME"
