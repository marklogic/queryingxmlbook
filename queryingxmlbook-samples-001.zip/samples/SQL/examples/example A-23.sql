-- Example A-23 


SELECT
  XMLELEMENT(NAME "movie-details",
    XMLFOREST(
      title AS "title" ,
      year_released AS "yearReleased" ,
      running_time AS "runningTime")
    ) AS "Movie Details"
  FROM movies
  WHERE
    year_released = 1997
