-- Example A-35


SELECT result.* 
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producer1" VARCHAR(12) PATH 'producer[1]/familyName' ,
      "producer2" VARCHAR(12) PATH 'producer[2]/familyName' DEFAULT 'none',
      "producer3" VARCHAR(12) PATH 'producer[3]/familyName' DEFAULT 'none'
  ) AS result
ORDER BY
  result."producer1"

