-- Example A-20 


SELECT
  XMLELEMENT(NAME "title", title) AS "Movie Titles"
  FROM movies



