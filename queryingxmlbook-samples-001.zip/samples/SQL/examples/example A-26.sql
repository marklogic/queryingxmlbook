-- Example A-26 


SELECT
  XMLCONCAT(
      XMLELEMENT("givenName", given_name) ,
      XMLELEMENT("familyName", family_name) ,
      XMLELEMENT("otherNames", other_names)
      ) AS "Producer Details"
  FROM persons
  WHERE
    id IN (
      SELECT distinct(producer_id) FROM movies_producers
      WHERE movie_id IN (
        SELECT id FROM movies WHERE running_time > 125
        )
      )

