-- Example A-29


CREATE TABLE movies_xml AS (
  SELECT id, result.column_value AS movie
  FROM
    all_movies_xml ,
    XMLTABLE(
      'for $m in
        $col/movies/movie
      return
        $m'
      PASSING all_movies_xml.all_movies AS "col"
    ) AS result
  )



