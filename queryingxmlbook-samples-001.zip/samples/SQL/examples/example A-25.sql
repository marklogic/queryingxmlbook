-- Example A-25 


SELECT
  XMLELEMENT(NAME "producer-details",
    XMLFOREST(
      given_name AS "givenName" ,
      family_name AS "familyName" ,
      other_names AS "otherNames"
      )
    ) AS "Producer Details"
  FROM persons
  WHERE
    id IN (
      SELECT distinct(producer_id) FROM movies_producers
      WHERE movie_id IN (
        SELECT id FROM movies WHERE running_time > 125
        )
      )

