-- Example A-32


SELECT result.*
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m/title'
    PASSING movies_xml.movie AS "col"
  ) AS result
