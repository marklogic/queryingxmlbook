-- Example A-28


SELECT
  XMLQUERY(
    'for $m in
      $col/movie
    return
      $m/title'
    PASSING movie AS "col"
    RETURNING CONTENT
  ) AS "Movie Titles"
FROM movies_xml


