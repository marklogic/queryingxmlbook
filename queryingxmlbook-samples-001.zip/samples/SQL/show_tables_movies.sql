set linesize 132
set pages 300

column id format 99
column title format a20
column my_stars format 99
column year_released format 9999
column running_time format 9999
column studio format a20
column tagline format a30
column plot_summary format a40
column aspect_ratio format a6

SELECT
  ID ,
  TITLE ,
  MY_STARS,
  YEAR_RELEASED,
  RUNNING_TIME,
  MPAA_RATING ,
  ASPECT_RATIO
FROM
  MOVIES
ORDER BY
  ID
/

column studio format a17
column other_sound format a35
SELECT
  ID ,
  STUDIO ,
  DOLBY_DIGITAL_51 ,
  DTS_51 ,
  THX ,
  OTHER_SOUND
FROM
  MOVIES
ORDER BY
  ID
/

SELECT
  ID ,
  TAGLINE ,
  concat( substr(PLOT_SUMMARY, 1, 50), ' ...') PLOT_SUMMARY
FROM
  MOVIES
ORDER BY
  ID
/
  
set pages 3000
column other_names format a12
SELECT * FROM PERSONS 
/

column character format a40
SELECT * FROM MOVIES_CAST 
/

column other format a40
SELECT * FROM MOVIES_SOUND 
/

SELECT * FROM MOVIES_PRODUCERS
/

SELECT * FROM MOVIES_DIRECTORS
/

SELECT * FROM MOVIES_WRITERS
/



  