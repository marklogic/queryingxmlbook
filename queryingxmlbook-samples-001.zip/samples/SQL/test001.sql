set pages 200
column title format a20
select movies.title title, persons.family_name name, persons.given_name
from 
  movies, movies_producers, persons
where 
  movies.id = movies_producers.movie_id and
  movies_producers.person_id = persons.id
order by
  title
