set long 20000
column review format a50
SELECT * from REVIEWS_XML
/

