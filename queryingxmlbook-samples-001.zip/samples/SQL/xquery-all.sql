


-- 15-10 with all_movies_xml

SELECT
  XMLQUERY(
    'for $m in
      $col/movies/movie
    return
      $m/title'
    PASSING all_movies AS "col"
    RETURNING CONTENT
  ) AS result
FROM all_movies_xml
/

-- 1 row

-- 15-10 with movies_xml

SELECT
  XMLQUERY(
    'for $m in
      $col/movie
    return
      $m/title'
    PASSING movie AS "col"
    RETURNING CONTENT
  ) AS "Movie Titles"
FROM movie_xml
/

-- 10 rows

-- 15-12

SELECT
  AVG(
    XMLCAST(
      XMLQUERY(
        'for $m in
          $col/movie
        return
          $m/runningTime/text()'
        PASSING movie AS "col"
        RETURNING CONTENT
        ) AS decimal(8,1)
      ) 
  ) AS "avgRunningTime"
FROM MOVIES_XML

-- 15-12

SELECT
  AVG(
    XMLCAST(
      XMLQUERY(
        'for $m in
          $col/movie
        return
          $m/runningTime/text()'
        PASSING movie AS "col"
        RETURNING CONTENT
        ) AS result
      ) AS decimal(8,1)
  ) AS "avgRunningTime"
FROM movies_xml
/

-- 15-13

SELECT '**'||
  XMLQUERY(
    'for $m in
      $col/movie
     let $producers := $m/producer
     where $m/yearReleased < 1980
    return
      <output>
        {$m/title}
        {for $p in $producers
           return
             <prodFullName>
               {concat(
                 $p/givenName,
                 " ",
                 $p/familyName
                )
               }
             </prodFullName>
        }
      </output>'
    PASSING movie AS "col"
    RETURNING CONTENT
  )  || '**' AS "Producers" 
  FROM movies_xml

-- 15-14

SELECT result.*
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m/title'
    PASSING movies_xml.movie AS "col"
  ) AS result

-- 15-15

column title format a30

SELECT result.*
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "runningTime" INTEGER PATH 'runningTime' ,
      "yearReleased" INTEGER PATH 'yearReleased'
  ) AS result
ORDER BY
  result."runningTime"
/

-- 15-16

SELECT result.*
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) ,
      "runningTime" INTEGER ,
      "yearReleased" INTEGER ,
      "producer[1]/familyName" VARCHAR(20)
  ) AS result ("TITLE", "RUNNINGTIME", "YEARRELEASED", "PRODUCER")
ORDER BY
  result."RUNNINGTIME"
/

-- 15-17

SELECT result.* 
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producer1" VARCHAR(12) PATH 'producer[1]/familyName' ,
      "producer2" VARCHAR(12) PATH 'producer[2]/familyName' DEFAULT 'none',
      "producer3" VARCHAR(12) PATH 'producer[3]/familyName' DEFAULT 'none'
  ) AS result
ORDER BY
  result."producer1"
/

-- 15-18

SELECT result.* 
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    where $m/yearReleased < 1980
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producers" XMLTYPE PATH 'producer'
  ) AS result
/

-- 15-19

SELECT result."title", result2.* FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    where
      contains($m/title, "Alien")
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producers" XMLTYPE PATH 'producer'
  ) AS result ,
  XMLTABLE(
    'for $prod in $p/producer
     return
      $prod'
    PASSING result."producers" AS "p"
    COLUMNS
      "ord" FOR ORDINALITY ,
      "familyName" VARCHAR(20) PATH 'familyName'
  ) AS result2
/

-- 15-20

SELECT result.* FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "title" VARCHAR(80) PATH 'title' ,
      "producerF" VARCHAR(12) PATH 'producer[1]/familyName' ,
      "producerG" VARCHAR(12) PATH 'producer[1]/givenName' ,
      "producerO" VARCHAR(12) PATH 'producer[1]/otherNames' DEFAULT 'none'
  ) AS result
/

-- 15-21 -- not shown in Appendix A

SELECT 
  DISTINCT result.* 
FROM
  movies_xml ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m/producer'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "ID" FOR ORDINALITY ,
      "familyName" VARCHAR(12) PATH 'familyName' ,
      "givenName" VARCHAR(12) PATH 'givenName' DEFAULT 'none' ,
      "otherNames" VARCHAR(12) PATH 'otherNames' DEFAULT 'none'
  ) AS result

/

-- 15-22

-- Note: 15-22 in text does not yield DISTINCT producers

DROP SEQUENCE producers_seq
/
CREATE SEQUENCE producers_seq
/

SELECT producers_seq.nextval AS id, p.*
from dual d, 
(
  SELECT DISTINCT
    result.family_name,
    result.given_name,
    result.other_names
  FROM
    movies_xml ,
    XMLTABLE(
      '$col/movie/producer'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "FAMILY_NAME" VARCHAR(12) PATH 'familyName' ,
        "GIVEN_NAME"  VARCHAR(12) PATH 'givenName' DEFAULT 'none' ,
        "OTHER_NAMES" VARCHAR(12) PATH 'otherNames' DEFAULT 'none'
    ) AS result 
  ORDER BY
    result.family_name
  )  p
/ 



-- 15-23 movies-producers, given a table producers as in previous example

SELECT 
  movies_xml.id AS "MOVIE",
  producers.id AS "PRODUCER"
FROM
  movies_xml ,
  producers ,
  XMLTABLE(
    'for $m in
      $col/movie
    return
      $m/producer'
    PASSING movies_xml.movie AS "col"
    COLUMNS
      "familyName" VARCHAR(12),
      "givenName" VARCHAR(12) ,
      "otherNames" VARCHAR(12)
  ) AS result
WHERE
  result."familyName" = producers."familyName" AND
  result."givenName" = producers."givenName" 
/

-- From here we start creating tables for use in other examples

DROP SEQUENCE movies_seq
/
CREATE SEQUENCE movies_seq
/
DROP TABLE movies
/
CREATE TABLE movies AS (
SELECT 
  movies_seq.nextval AS id, 
  m.*
FROM dual d, 
(
  SELECT 
    result.*
  FROM
    movies_xml ,
    XMLTABLE(
      '$col/movie'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "TITLE"            VARCHAR(40)   PATH 'title' ,
        "MY_STARS"         INTEGER       PATH '@myStars' ,
        "YEAR_RELEASED"    INTEGER       PATH 'yearReleased' ,
        "RUNNING_TIME"     INTEGER       PATH 'runningTime' ,
        "STUDIO"           VARCHAR(60)   PATH 'studio' ,
        "TAGLINE"          VARCHAR(200)  PATH 'tagLine' ,
        "PLOT_SUMMARY"     VARCHAR(1000) PATH 'plotSummary' ,
        "MPAA_RATING"      VARCHAR(5)    PATH 'MPAArating' ,
        "ASPECT_RATIO"     VARCHAR(8)    PATH 'aspectRatio' ,
        "DOLBY_DIGITAL_51" VARCHAR(5)    PATH 'sound/dolbyDigital5.1' ,
        "DTS_51"           VARCHAR(5)    PATH 'sound/DTS5.1' ,
        "THX"              VARCHAR(5)    PATH 'sound/THX' ,
        "OTHER_SOUND"      VARCHAR(80)   PATH 'sound/otherSound'
    ) AS result 
  ORDER BY
    result.title
  )  m
)
/ 

-- PERSONS table

-- Note: if you use DEFAULT 'none', then a person who has no otherNames (e.g. Walter Hill, writer on Aliens)
will be treated as different from a person who has an otherNames that is empty (Walter Hill, producer of Alien 3).
This is probably not what you want.
DEFAULT '' means they match, so DISTINCT works correctly.

DROP SEQUENCE persons_seq
/
CREATE SEQUENCE persons_seq
/

DROP TABLE persons
/

CREATE TABLE persons AS (
SELECT persons_seq.nextval AS id, p.*
FROM dual d, 
(
  SELECT DISTINCT
    result.family_name,
    result.given_name,
    result.other_Names
  FROM
    movies_xml ,
    XMLTABLE(
      '($col//producer, $col//director, $col//cast, $col//writer)'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "FAMILY_NAME" VARCHAR(12) PATH 'familyName' ,
        "GIVEN_NAME"  VARCHAR(12) PATH 'givenName' DEFAULT '' ,
        "OTHER_NAMES" VARCHAR(12) PATH 'otherNames' DEFAULT ''
    ) AS result 
  ORDER BY
    result.family_name
  )  p
)
/ 

-- MOVIES_PRODUCERS from PERSONS, MOVIES, and MOVIES_XML
DROP TABLE movies_producers
/
CREATE TABLE movies_producers AS (
SELECT
  movies.id AS movie_id ,
  persons.id AS producer_id
FROM
  persons , 
  movies ,
  movies_xml , 
    XMLTABLE(
      'for $p in $col/movie/producer
       return 
         <producer-info>
           <movie-title>{ $p/../title }</movie-title>
           <movie-year-released>{ $p/../yearReleased }</movie-year-released>
           <family>{ $p/familyName }</family>
           <given>{ $p/givenName }</given>
           <other>{ $p/otherNames }</other>
         </producer-info>'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "TITLE" VARCHAR(100) PATH '/producer-info/movie-title' ,
        "YEAR_RELEASED" VARCHAR(100) PATH '/producer-info/movie-year-released' ,
        "FAMILY_NAME" VARCHAR(100) PATH '/producer-info/family' ,
        "GIVEN_NAME" VARCHAR(100) PATH '/producer-info/given' DEFAULT '' ,
        "OTHER_NAMES" VARCHAR(100) PATH '/producer-info/other' DEFAULT ''
    ) AS result 
WHERE
  result.title = movies.title and
  result.year_released = movies.year_released and
  result.family_name = persons.family_name and
  result.given_name = persons.given_name 
)
/
set pages 300
select * from movies_producers order by movie_id asc;

  
column title format a30
DROP TABLE t2;
CREATE TABLE t2 AS (
SELECT DISTINCT
  result.title, movies.id as movies_id, persons.id as persons_id
FROM
  movies ,
  persons ,
  movies_xml , 
    XMLTABLE(
      'for $p in $col/movie/producer
       return 
         <producer-info>
           <movie-title>{ $p/../title }</movie-title>
           <movie-year-released>{ $p/../yearReleased }</movie-year-released>
           <family>{ $p/familyName }</family>
           <given>{ $p/givenName }</given>
         </producer-info>'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "TITLE" VARCHAR(100) PATH '/producer-info/movie-title' ,
        "YEAR_RELEASED" VARCHAR(100) PATH '/producer-info/movie-year-released' ,
        "FAMILY_NAME" VARCHAR(100) PATH '/producer-info/family' ,
        "GIVEN_NAME" VARCHAR(100) PATH '/producer-info/given' DEFAULT '' ,
        "OTHER_NAMES" VARCHAR(100) PATH '/producer-info/other' DEFAULT ''
    ) AS result 
  where movies.title = result.title and
  persons.family_name = result.family_name and
  persons.given_name = result.given_name
)
/

select movies.title, family_name
from
  movies, persons, t2
where
  movies.id=t2.movies_id and
  persons.id = t2.persons_id
order by 1, 2
/

-- MOVIES_DIRECTORS

-- MOVIES_DIRECTORS from PERSONS, MOVIES, and MOVIES_XML
DROP TABLE movies_directors
/
CREATE TABLE movies_directors AS (
SELECT
  movies.id AS movie_id ,
  persons.id AS director_id
FROM
  persons , 
  movies ,
  movies_xml , 
    XMLTABLE(
      'for $d in $col/movie/director
       return 
         <director-info>
           <movie-title>{ $d/../title }</movie-title>
           <movie-year-released>{ $d/../yearReleased }</movie-year-released>
           <family>{ $d/familyName }</family>
           <given>{ $d/givenName }</given>
           <other>{ $d/otherNames }</other>
         </director-info>'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "TITLE" VARCHAR(100) PATH '/director-info/movie-title' ,
        "YEAR_RELEASED" VARCHAR(100) PATH '/director-info/movie-year-released' ,
        "FAMILY_NAME" VARCHAR(100) PATH '/director-info/family' ,
        "GIVEN_NAME" VARCHAR(100) PATH '/director-info/given' DEFAULT '' ,
        "OTHER_NAMES" VARCHAR(100) PATH '/director-info/other' DEFAULT ''
    ) AS result 
WHERE
  result.title = movies.title and
  result.year_released = movies.year_released and
  result.family_name = persons.family_name and
  result.given_name = persons.given_name 
)
/

select * from movies_directors order by movie_id asc;


-- MOVIES_CAST

-- MOVIES_CAST from PERSONS, MOVIES, and MOVIES_XML
DROP TABLE movies_cast
/
DROP TABLE movies_cast
/
CREATE TABLE movies_cast AS (
SELECT
  movies.id AS movie_id ,
  persons.id AS cast_id ,
  result.mf AS mf ,
  result.character AS character
FROM
  persons , 
  movies ,
  movies_xml , 
    XMLTABLE(
      'for $c in $col/movie/cast
       return 
         <cast-info>
           <movie-title>{ $c/../title }</movie-title>
           <movie-year-released>{ $c/../yearReleased }</movie-year-released>
           <family>{ $c/familyName }</family>
           <given>{ $c/givenName }</given>
           <other>{ $c/otherNames }</other>
           <maleOrFemale>{ $c/maleOrFemale }</maleOrFemale>
           <character>{ $c/character }</character>
         </cast-info>'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "TITLE" VARCHAR(100) PATH '/cast-info/movie-title' ,
        "YEAR_RELEASED" VARCHAR(100) PATH '/cast-info/movie-year-released' ,
        "FAMILY_NAME" VARCHAR(100) PATH '/cast-info/family' ,
        "GIVEN_NAME" VARCHAR(100) PATH '/cast-info/given' DEFAULT '' ,
        "OTHER_NAMES" VARCHAR(100) PATH '/cast-info/other' DEFAULT '' ,
        "MF"  VARCHAR(6) PATH '/cast-info/maleOrFemale' ,
        "CHARACTER"  VARCHAR(100) PATH '/cast-info/character'
    ) AS result 
WHERE
  result.title = movies.title and
  result.year_released = movies.year_released and
  result.family_name = persons.family_name and
  result.given_name = persons.given_name 
)
/

column character format a40
column mf format a6
select * from movies_cast order by movie_id asc;

-- MOVIES_WRITER

-- MOVIES_WRITER from PERSONS, MOVIES, and MOVIES_XML
DROP TABLE movies_writers
/
CREATE TABLE movies_writers AS (
SELECT
  movies.id AS movie_id ,
  persons.id AS writer_id ,
  result.story_or_screenplay AS story_or_screenplay
FROM
  persons , 
  movies ,
  movies_xml , 
    XMLTABLE(
      'for $w in $col/movie/writer
       return 
         <writer-info>
           <movie-title>{ $w/../title }</movie-title>
           <movie-year-released>{ $w/../yearReleased }</movie-year-released>
           <family>{ $w/familyName }</family>
           <given>{ $w/givenName }</given>
           <other>{ $w/otherNames }</other>
           <st>{ if ($w/storyOrScreenplay = "story") then "ST" else "SC" }</st>
         </writer-info>'
      PASSING movies_xml.movie AS "col"
      COLUMNS
        "TITLE" VARCHAR(100) PATH '/writer-info/movie-title' ,
        "YEAR_RELEASED" VARCHAR(100) PATH '/writer-info/movie-year-released' ,
        "FAMILY_NAME" VARCHAR(100) PATH '/writer-info/family' ,
        "GIVEN_NAME" VARCHAR(100) PATH '/writer-info/given' DEFAULT '' ,
        "OTHER_NAMES" VARCHAR(100) PATH '/writer-info/other' DEFAULT '' ,
        "STORY_OR_SCREENPLAY"  VARCHAR(100) PATH '/writer-info/st'
    ) AS result 
WHERE
  result.title = movies.title and
  result.year_released = movies.year_released and
  result.family_name = persons.family_name and
  result.given_name = persons.given_name 
)
/

column story_or_screenplay format a20
select * from movies_writers order by movie_id asc;

-- test derived tables:

select 
  movies.id, movies.title, persons.family_name
from
  movies,
  persons,
  movies_producers
where
  movies.id = movies_producers.movie_id and
  persons.id = movies_producers.producer_id
order by
  movies.title
/

select 
  movies.id, movies.title, persons.family_name
from
  movies,
  persons,
  movies_directors
where
  movies.id = movies_directors.movie_id and
  persons.id = movies_directors.director_id
order by
  movies.title
/

select 
  movies.id, movies.title, persons.family_name, movies_writers.story_or_screenplay
from
  movies,
  persons,
  movies_writers
where
  movies.id = movies_writers.movie_id and
  persons.id = movies_writers.writer_id
order by
  movies.title
/

column title format a20
column character format a20
select 
  movies.id, movies.title, persons.family_name, movies_cast.character
from
  movies,
  persons,
  movies_cast
where
  movies.id = movies_cast.movie_id and
  persons.id = movies_cast.cast_id
order by
  movies.title
/

-- re-create movies-we-own.xml

SELECT
XMLELEMENT(NAME "movie"),
  XMLELEMENT(NAME "title", movies.title),
  XMLELEMENT(NAME "producer",
    XMLELEMENT(NAME "givenName", persons.given_name) ,
    XMLELEMENT(NAME "familyName", persons.family_name) ,
    XMLELEMENT(NAME "otherNames", persons.other_names)
    ) AS "Producer Details"
  FROM persons, movies, movies_producers
  WHERE
     movies.id = movies_producers.movie_id and
     persons.id = movies_producers.PRODUCER_ID 
/

-- this works, as far as it goes
SELECT
  XMLELEMENT(NAME "movie",
    XMLELEMENT(NAME "title", title) ,
    XMLELEMENT(NAME "producers",
      (SELECT
        XMLAGG(
          XMLELEMENT( "producerF", persons.family_name)
          )
        FROM 
          persons, movies_producers
        WHERE
          movies.id = movies_producers.movie_id and
          persons.id = movies_producers.producer_id)
       )
   )
FROM 
  movies
/

set pages 3000
set long 20000
set lines 80


SELECT 
XMLELEMENT(NAME "movies",
XMLAGG(
  XMLELEMENT(NAME "movie",
    XMLATTRIBUTES(my_stars AS "myStars") ,
    XMLELEMENT(NAME "title", title) ,
    XMLELEMENT(NAME "yearReleased", year_released) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "director" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames"
              )
            )
          )
        FROM 
          persons, movies_directors
        WHERE
          movies.id = movies_directors.movie_id and
          persons.id = movies_directors.director_id
        ) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "producer" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames"
              )
            )
          )
        FROM 
          persons, movies_producers
        WHERE
          movies.id = movies_producers.movie_id and
          persons.id = movies_producers.producer_id
        ) ,
    XMLELEMENT(NAME "runningTime", running_time) ,
    XMLELEMENT(NAME "studio", studio) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "cast" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames" ,
              movies_cast.mf AS "maleOrFemale" ,
              movies_cast.character AS "character"
              )
            )
          )
        FROM 
          persons, movies_cast
        WHERE
          movies.id = movies_cast.movie_id and
          persons.id = movies_cast.cast_id
        ) ,
      XMLELEMENT( "sound" ,
        XMLFOREST(
          dolby_digital_51 AS "dolbyDigital5.1" ,
          DTS_51 AS "DTS5.1" ,
          THX AS "THX" ,
          other_sound AS "otherSound"
          )
        ) ,
    XMLELEMENT(NAME "aspectRatio", aspect_ratio) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "writer" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames" ,
              replace(
                replace(movies_writers.story_or_screenplay, 'ST', 'story') ,
                'SC',
                'screenplay'
                )
              AS "storyOrScreenplay"
              )
            )
          )
        FROM 
          persons, movies_writers
        WHERE
          movies.id = movies_writers.movie_id and
          persons.id = movies_writers.writer_id
        ) ,
    XMLELEMENT(NAME "tagLine", tagline) ,
    XMLELEMENT(NAME "plotSummary", plot_summary) ,
    XMLELEMENT(NAME "MPAArating", mpaa_rating)
    ) 
  )
) AS "movies-we-own"
FROM 
  movies
ORDER BY
  id asc
/

