INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (1, 'Amicarella', 'John', 'C.' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (2, 'Ledoux', 'Patrice', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (3, 'Smith', 'Iain', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (4, 'Folsey', 'George, Jr.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (5, 'Guber', 'Peter', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (6, 'Peters', 'Jon', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (7, 'Coppola', 'Francis Ford', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (8, 'Kurtz', 'Gary', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (9, 'Cohen', 'Bruce', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (10, 'Jinks', 'Dan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (11, 'Bernstein', 'Armyan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (12, 'Peterson', 'Wolfgang', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (13, 'Katz', 'Gail', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (14, 'Shestack', 'Jon', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (15, 'Carroll', 'Gordon', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (16, 'Giler', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (17, 'Hurd', 'Gale Ann', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (18, 'Hill', 'Walter', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (19, 'Badalato', 'Bill', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (20, 'Simmons', 'Matty', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (21, 'Reitman', 'Ivan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (22, 'Besson', 'Luc', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (23, 'Landis', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (24, 'Lucas', 'George', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (25, 'Mendes', 'Sam', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (26, 'Peterson', 'Wolfgang', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (27, 'Scott', 'Ridley', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (28, 'Cameron', 'James', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (29, 'Fincher', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (30, 'Jeunet', 'Jean-Pierre', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (31, 'Willis', 'Bruce', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (32, 'Oldman', 'Gary', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (33, 'Holm', 'Ian', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (34, 'Jovovich', 'Milla', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (35, 'Tucker', 'Chris', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (36, 'Naughton', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (37, 'Agutter', 'Jenny', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (38, 'Dunne', 'Griffin', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (39, 'Woodvine', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (40, 'Dreyfuss', 'Richard', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (41, 'Howard', 'Ronny', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (42, 'Le Mat', 'Paul', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (43, 'Smith', 'Charlie Martin', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (44, 'Spacey', 'Kevin', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (45, 'Bening', 'Annette', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (46, 'Birch', 'Thora', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (47, 'Suvari', 'Mena', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (48, 'Bentley', 'Wes', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (49, 'Ford', 'Harrison', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (50, 'Close', 'Glenn', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (51, 'Macy', 'William H.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (52, 'Matthews', 'Liesel', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (53, 'Crewson', 'Wendy', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (54, 'Weaver', 'Sigourney', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (55, 'Skerritt', 'Tom', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (56, 'Cartwright', 'Veronica', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (57, 'Stanton', 'Harry Dean', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (58, 'Hurt', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (59, 'Biehn', 'Micheal', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (60, 'Reiser', 'Paul', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (61, 'Henriksen', 'Lance', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (62, 'Dutton', 'Charles S.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (63, 'Ryder', 'Winina', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (64, 'Perlman', 'Ron', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (65, 'Belushi', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (66, 'Matheson', 'Tim', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (67, 'Vernon', 'John', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (68, 'Kamen', 'Robert', 'Mark' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (69, 'Katz', 'Gloria', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (70, 'Huyck', 'Willard', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (71, 'Ball', 'Alan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (72, 'Marlowe', 'Andrew W.', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (73, 'O''Bannon', 'Dan', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (74, 'Shusett', 'Ronald', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (75, 'Giler', 'David', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (76, 'Hill', 'Walter', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (77, 'Ward', 'Vincent', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (78, 'Whedon', 'Joss', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (79, 'Kenney', 'Douglas', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (80, 'Ramis', 'Harold', '' )
      /
      
INSERT INTO PERSONS (
      ID ,
      FAMILY_NAME ,
      GIVEN_NAME ,
      OTHER_NAMES
      )
      VALUES (81, 'Miller', 'Chris', '' )
      /
      