set echo on
spool cre_tables_movies_xml.log

DROP TABLE all_movies_xml;

CREATE TABLE all_movies_xml (
  ID                 INT ,
  ALL_MOVIES         XMLType
)
/

-- requires CREATE DIRECTORY privilege
CREATE DIRECTORY xmldir AS 'C:\stage'
/

INSERT INTO all_movies_xml ( 
  ID , 
  ALL_MOVIES 
  ) 
VALUES ( 
  1 , 
  XMLType( bfilename('XMLDIR', 'movies-we-own.xml'), nls_charset_id('AL32UTF8') )
  )
/

COMMIT
/

SELECT
  XMLQUERY(
    'for $m in
      $col/movies
    return
      $m/movie'
    PASSING all_movies AS "col"
    RETURNING CONTENT
  ) AS result
FROM all_movies_xml
/

DROP SEQUENCE movies_id_seq
/
CREATE SEQUENCE movies_id_seq
/
DROP TABLE movies_xml
/
CREATE TABLE movies_xml AS (
  SELECT 
    movies_id_seq.nextval as id, 
    result.column_value AS movie
  FROM
    all_movies_xml ,
    XMLTABLE(
      'for $m in
        $col/movies/movie
      return
        $m'
      PASSING all_movies_xml.all_movies AS "col"
    ) AS result
  )
/
describe movies_xml
select id from movies_xml
/


spool off
