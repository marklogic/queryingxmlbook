INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 1)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 2)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (1, 3)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 4)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 5)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (2, 6)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (3, 7)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (3, 8)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (4, 9)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (4, 10)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 11)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 12)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 13)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (5, 14)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (6, 15)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (6, 16)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (7, 17)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 15)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 16)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (8, 18)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 15)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 16)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 18)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (9, 19)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (10, 20)
       /
       
INSERT INTO MOVIES_PRODUCERS (
       MOVIE_ID ,
       PERSON_ID 
       )
       VALUES (10, 21)
       /
       