-- Data 1 12 Translate Relational Data Into XML: Check

SELECT 
XMLELEMENT(NAME "movies",
XMLAGG(
  XMLELEMENT(NAME "movie",
    XMLATTRIBUTES(my_stars AS "myStars") ,
    XMLELEMENT(NAME "title", title) ,
    XMLELEMENT(NAME "yearReleased", year_released) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "director" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames"
              )
            )
          )
        FROM 
          persons, movies_directors
        WHERE
          movies.id = movies_directors.movie_id and
          persons.id = movies_directors.director_id
        ) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "producer" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames"
              )
            )
          )
        FROM 
          persons, movies_producers
        WHERE
          movies.id = movies_producers.movie_id and
          persons.id = movies_producers.producer_id
        ) ,
    XMLELEMENT(NAME "runningTime", running_time) ,
    XMLELEMENT(NAME "studio", studio) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "cast" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames" ,
              movies_cast.mf AS "maleOrFemale" ,
              movies_cast.character AS "character"
              )
            )
          )
        FROM 
          persons, movies_cast
        WHERE
          movies.id = movies_cast.movie_id and
          persons.id = movies_cast.cast_id
        ) ,
      XMLELEMENT( "sound" ,
        XMLFOREST(
          dolby_digital_51 AS "dolbyDigital5.1" ,
          DTS_51 AS "DTS5.1" ,
          THX AS "THX" ,
          other_sound AS "otherSound"
          )
        ) ,
    XMLELEMENT(NAME "aspectRatio", aspect_ratio) ,
      (SELECT
        XMLAGG(
          XMLELEMENT( "writer" ,
            XMLFOREST(
              persons.family_name AS "familyName" ,
              persons.given_name AS "givenName" ,
              persons.other_names AS "otherNames" ,
              replace(
                replace(movies_writers.story_or_screenplay, 'ST', 'story'),
                'SC',
                'screenplay'
                )
              AS "storyOrScreenplay"
              )
            )
          )
        FROM 
          persons, movies_writers
        WHERE
          movies.id = movies_writers.movie_id and
          persons.id = movies_writers.writer_id
        ) ,
    XMLELEMENT(NAME "tagLine", tagline) ,
    XMLELEMENT(NAME "plotSummary", plot_summary) ,
    XMLELEMENT(NAME "MPAArating", mpaa_rating)
    ) 
  )
) AS "movies-we-own"
FROM 
  movies
