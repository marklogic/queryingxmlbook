set echo on
spool redo.log

@drop_tables_movies.sql

@cre_tables_movies.sql

@ins_movies.sql

@ins_persons.sql

@ins_movies_cast.sql

@ins_movies_sound.sql

@ins_movies_producers.sql

@ins_movies_directors.sql

@ins_movies_writers.sql

@pop_tables_movies.sql

spool off
